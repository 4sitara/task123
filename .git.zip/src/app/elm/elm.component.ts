import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-elm',
  templateUrl: './elm.component.html',
  styleUrls: ['./elm.component.scss']
})
export class ElmComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
