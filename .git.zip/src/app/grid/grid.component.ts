import { Component, OnInit } from '@angular/core';
export interface Tile {
  color: string;
  cols: number;
  rows: number;
  text: string;
}

@Component({
  selector: 'app-grid',
  templateUrl: './grid.component.html',
  styleUrls: ['./grid.component.scss']
})
export class GridComponent  {
  tiles: Tile[] = [
    {text: 'One', cols: 4, rows: 1, color: 'black'},
    {text: 'Two', cols: 1, rows: 2, color: 'black'},
    {text: 'Three', cols: 1, rows: 1, color: 'black'},
    {text: 'Four', cols: 2, rows: 1, color: 'black'},
    {text: 'Four', cols: 2, rows: 1, color: 'black'},
    {text: 'Four', cols: 2, rows: 1, color: 'black'},

  ];
}

 