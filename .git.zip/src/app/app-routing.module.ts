import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { FormComponent } from './form/form.component';  
import { PageComponent } from './page/page.component'; 
import { ColmComponent } from './colm/colm.component'; 
import { ElmComponent } from './elm/elm.component';
import { PortComponent } from './port/port.component';
import { TempComponent } from './temp/temp.component';
import { RentComponent } from './rent/rent.component'; 
import { NavComponent } from './nav/nav.component';



const routes: Routes = [

  { path: 'page', component: PageComponent },

  { path: 'colm', component: ColmComponent },

  { path: 'page', component: PageComponent },
  { path: 'elm', component:  ElmComponent },
  { path: 'form', component: FormComponent },

  { path: 'port', component: PortComponent },
  { path: 'rent', component:  RentComponent},

  { path: 'temp', component: TempComponent},



];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
export const routingComponents = [NavComponent,FormComponent,ColmComponent,PageComponent,ElmComponent,PortComponent,RentComponent, TempComponent]
