import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ColmComponent } from './colm.component';

describe('ColmComponent', () => {
  let component: ColmComponent;
  let fixture: ComponentFixture<ColmComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ColmComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ColmComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
