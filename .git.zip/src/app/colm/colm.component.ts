import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-colm',
  templateUrl: './colm.component.html',
  styleUrls: ['./colm.component.scss']
})
export class ColmComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
